package com.ebanking.testsystem;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 *this defines the whole service
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: Transaction.proto")
public final class TransactionGrpc {

  private TransactionGrpc() {}

  public static final String SERVICE_NAME = "testsystem.Transaction";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.messageWithIntInside> getGetFirstIntMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetFirstInt",
      requestType = com.ebanking.testsystem.containsString.class,
      responseType = com.ebanking.testsystem.messageWithIntInside.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.messageWithIntInside> getGetFirstIntMethod() {
    io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString, com.ebanking.testsystem.messageWithIntInside> getGetFirstIntMethod;
    if ((getGetFirstIntMethod = TransactionGrpc.getGetFirstIntMethod) == null) {
      synchronized (TransactionGrpc.class) {
        if ((getGetFirstIntMethod = TransactionGrpc.getGetFirstIntMethod) == null) {
          TransactionGrpc.getGetFirstIntMethod = getGetFirstIntMethod = 
              io.grpc.MethodDescriptor.<com.ebanking.testsystem.containsString, com.ebanking.testsystem.messageWithIntInside>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "testsystem.Transaction", "GetFirstInt"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.containsString.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.messageWithIntInside.getDefaultInstance()))
                  .setSchemaDescriptor(new TransactionMethodDescriptorSupplier("GetFirstInt"))
                  .build();
          }
        }
     }
     return getGetFirstIntMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.messageWithIntInside> getGetFirstIntServerStreamingMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetFirstIntServerStreaming",
      requestType = com.ebanking.testsystem.containsString.class,
      responseType = com.ebanking.testsystem.messageWithIntInside.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.messageWithIntInside> getGetFirstIntServerStreamingMethod() {
    io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString, com.ebanking.testsystem.messageWithIntInside> getGetFirstIntServerStreamingMethod;
    if ((getGetFirstIntServerStreamingMethod = TransactionGrpc.getGetFirstIntServerStreamingMethod) == null) {
      synchronized (TransactionGrpc.class) {
        if ((getGetFirstIntServerStreamingMethod = TransactionGrpc.getGetFirstIntServerStreamingMethod) == null) {
          TransactionGrpc.getGetFirstIntServerStreamingMethod = getGetFirstIntServerStreamingMethod = 
              io.grpc.MethodDescriptor.<com.ebanking.testsystem.containsString, com.ebanking.testsystem.messageWithIntInside>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "testsystem.Transaction", "GetFirstIntServerStreaming"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.containsString.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.messageWithIntInside.getDefaultInstance()))
                  .setSchemaDescriptor(new TransactionMethodDescriptorSupplier("GetFirstIntServerStreaming"))
                  .build();
          }
        }
     }
     return getGetFirstIntServerStreamingMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.containsString> getGetFirstStringMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetFirstString",
      requestType = com.ebanking.testsystem.containsString.class,
      responseType = com.ebanking.testsystem.containsString.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.containsString> getGetFirstStringMethod() {
    io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString, com.ebanking.testsystem.containsString> getGetFirstStringMethod;
    if ((getGetFirstStringMethod = TransactionGrpc.getGetFirstStringMethod) == null) {
      synchronized (TransactionGrpc.class) {
        if ((getGetFirstStringMethod = TransactionGrpc.getGetFirstStringMethod) == null) {
          TransactionGrpc.getGetFirstStringMethod = getGetFirstStringMethod = 
              io.grpc.MethodDescriptor.<com.ebanking.testsystem.containsString, com.ebanking.testsystem.containsString>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "testsystem.Transaction", "GetFirstString"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.containsString.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.containsString.getDefaultInstance()))
                  .setSchemaDescriptor(new TransactionMethodDescriptorSupplier("GetFirstString"))
                  .build();
          }
        }
     }
     return getGetFirstStringMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.containsString> getGetSecondStringMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetSecondString",
      requestType = com.ebanking.testsystem.containsString.class,
      responseType = com.ebanking.testsystem.containsString.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString,
      com.ebanking.testsystem.containsString> getGetSecondStringMethod() {
    io.grpc.MethodDescriptor<com.ebanking.testsystem.containsString, com.ebanking.testsystem.containsString> getGetSecondStringMethod;
    if ((getGetSecondStringMethod = TransactionGrpc.getGetSecondStringMethod) == null) {
      synchronized (TransactionGrpc.class) {
        if ((getGetSecondStringMethod = TransactionGrpc.getGetSecondStringMethod) == null) {
          TransactionGrpc.getGetSecondStringMethod = getGetSecondStringMethod = 
              io.grpc.MethodDescriptor.<com.ebanking.testsystem.containsString, com.ebanking.testsystem.containsString>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "testsystem.Transaction", "GetSecondString"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.containsString.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.ebanking.testsystem.containsString.getDefaultInstance()))
                  .setSchemaDescriptor(new TransactionMethodDescriptorSupplier("GetSecondString"))
                  .build();
          }
        }
     }
     return getGetSecondStringMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static TransactionStub newStub(io.grpc.Channel channel) {
    return new TransactionStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static TransactionBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new TransactionBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static TransactionFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new TransactionFutureStub(channel);
  }

  /**
   * <pre>
   *this defines the whole service
   * </pre>
   */
  public static abstract class TransactionImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     *unary rpc
     * </pre>
     */
    public void getFirstInt(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.messageWithIntInside> responseObserver) {
      asyncUnimplementedUnaryCall(getGetFirstIntMethod(), responseObserver);
    }

    /**
     */
    public void getFirstIntServerStreaming(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.messageWithIntInside> responseObserver) {
      asyncUnimplementedUnaryCall(getGetFirstIntServerStreamingMethod(), responseObserver);
    }

    /**
     */
    public void getFirstString(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.containsString> responseObserver) {
      asyncUnimplementedUnaryCall(getGetFirstStringMethod(), responseObserver);
    }

    /**
     */
    public void getSecondString(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.containsString> responseObserver) {
      asyncUnimplementedUnaryCall(getGetSecondStringMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetFirstIntMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.ebanking.testsystem.containsString,
                com.ebanking.testsystem.messageWithIntInside>(
                  this, METHODID_GET_FIRST_INT)))
          .addMethod(
            getGetFirstIntServerStreamingMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.ebanking.testsystem.containsString,
                com.ebanking.testsystem.messageWithIntInside>(
                  this, METHODID_GET_FIRST_INT_SERVER_STREAMING)))
          .addMethod(
            getGetFirstStringMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.ebanking.testsystem.containsString,
                com.ebanking.testsystem.containsString>(
                  this, METHODID_GET_FIRST_STRING)))
          .addMethod(
            getGetSecondStringMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.ebanking.testsystem.containsString,
                com.ebanking.testsystem.containsString>(
                  this, METHODID_GET_SECOND_STRING)))
          .build();
    }
  }

  /**
   * <pre>
   *this defines the whole service
   * </pre>
   */
  public static final class TransactionStub extends io.grpc.stub.AbstractStub<TransactionStub> {
    private TransactionStub(io.grpc.Channel channel) {
      super(channel);
    }

    private TransactionStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TransactionStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new TransactionStub(channel, callOptions);
    }

    /**
     * <pre>
     *unary rpc
     * </pre>
     */
    public void getFirstInt(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.messageWithIntInside> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetFirstIntMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getFirstIntServerStreaming(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.messageWithIntInside> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetFirstIntServerStreamingMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getFirstString(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.containsString> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetFirstStringMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getSecondString(com.ebanking.testsystem.containsString request,
        io.grpc.stub.StreamObserver<com.ebanking.testsystem.containsString> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetSecondStringMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   *this defines the whole service
   * </pre>
   */
  public static final class TransactionBlockingStub extends io.grpc.stub.AbstractStub<TransactionBlockingStub> {
    private TransactionBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private TransactionBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TransactionBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new TransactionBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     *unary rpc
     * </pre>
     */
    public com.ebanking.testsystem.messageWithIntInside getFirstInt(com.ebanking.testsystem.containsString request) {
      return blockingUnaryCall(
          getChannel(), getGetFirstIntMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.ebanking.testsystem.messageWithIntInside> getFirstIntServerStreaming(
        com.ebanking.testsystem.containsString request) {
      return blockingServerStreamingCall(
          getChannel(), getGetFirstIntServerStreamingMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.ebanking.testsystem.containsString getFirstString(com.ebanking.testsystem.containsString request) {
      return blockingUnaryCall(
          getChannel(), getGetFirstStringMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.ebanking.testsystem.containsString> getSecondString(
        com.ebanking.testsystem.containsString request) {
      return blockingServerStreamingCall(
          getChannel(), getGetSecondStringMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   *this defines the whole service
   * </pre>
   */
  public static final class TransactionFutureStub extends io.grpc.stub.AbstractStub<TransactionFutureStub> {
    private TransactionFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private TransactionFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TransactionFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new TransactionFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     *unary rpc
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.ebanking.testsystem.messageWithIntInside> getFirstInt(
        com.ebanking.testsystem.containsString request) {
      return futureUnaryCall(
          getChannel().newCall(getGetFirstIntMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.ebanking.testsystem.containsString> getFirstString(
        com.ebanking.testsystem.containsString request) {
      return futureUnaryCall(
          getChannel().newCall(getGetFirstStringMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_FIRST_INT = 0;
  private static final int METHODID_GET_FIRST_INT_SERVER_STREAMING = 1;
  private static final int METHODID_GET_FIRST_STRING = 2;
  private static final int METHODID_GET_SECOND_STRING = 3;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final TransactionImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(TransactionImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_FIRST_INT:
          serviceImpl.getFirstInt((com.ebanking.testsystem.containsString) request,
              (io.grpc.stub.StreamObserver<com.ebanking.testsystem.messageWithIntInside>) responseObserver);
          break;
        case METHODID_GET_FIRST_INT_SERVER_STREAMING:
          serviceImpl.getFirstIntServerStreaming((com.ebanking.testsystem.containsString) request,
              (io.grpc.stub.StreamObserver<com.ebanking.testsystem.messageWithIntInside>) responseObserver);
          break;
        case METHODID_GET_FIRST_STRING:
          serviceImpl.getFirstString((com.ebanking.testsystem.containsString) request,
              (io.grpc.stub.StreamObserver<com.ebanking.testsystem.containsString>) responseObserver);
          break;
        case METHODID_GET_SECOND_STRING:
          serviceImpl.getSecondString((com.ebanking.testsystem.containsString) request,
              (io.grpc.stub.StreamObserver<com.ebanking.testsystem.containsString>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class TransactionBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    TransactionBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.ebanking.testsystem.TestSystemImpl.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Transaction");
    }
  }

  private static final class TransactionFileDescriptorSupplier
      extends TransactionBaseDescriptorSupplier {
    TransactionFileDescriptorSupplier() {}
  }

  private static final class TransactionMethodDescriptorSupplier
      extends TransactionBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    TransactionMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (TransactionGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new TransactionFileDescriptorSupplier())
              .addMethod(getGetFirstIntMethod())
              .addMethod(getGetFirstIntServerStreamingMethod())
              .addMethod(getGetFirstStringMethod())
              .addMethod(getGetSecondStringMethod())
              .build();
        }
      }
    }
    return result;
  }
}
