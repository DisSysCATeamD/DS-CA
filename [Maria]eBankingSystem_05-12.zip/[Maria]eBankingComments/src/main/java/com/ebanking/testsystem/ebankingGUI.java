package com.ebanking.testsystem;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


import com.ebanking.testsystem.BalanceGrpc.BalanceBlockingStub;


import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;


import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionEvent;

public class ebankingGUI {

	private static BalanceBlockingStub blockingStub;	
	
	private JFrame frame;
	private JTextField textName1;
	private JTextField textName2;
	private JTextArea textResponse ;

	/*
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			//overide the run method of runnable
			public void run() {
				try {
					ebankingGUI window = new ebankingGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	/*
	 * Create the application.
	 */
	
	public ebankingGUI() {
		
		int port = 50052;
		String host = "localhost";
		
		ManagedChannel channel = ManagedChannelBuilder
				.forAddress(host, port)
				.usePlaintext()
				.build();

		//stubs -- generate from proto
		blockingStub = BalanceGrpc.newBlockingStub(channel);
		
		initialize();
		/*
		try {
			channel.shutdown().awaitTermination(50, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}


	private void initialize() {
		// TODO Auto-generated method stub
		frame = new JFrame();
		//Jframe is a window with a title bar
		frame.setTitle("Client - Service Controller");
		//set bounds can be done for frames panels and buttons
		frame.setBounds(100, 100, 500, 300);
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Box layout determines how components are laid out in the panel
		//Layout vertically in a col - box layout doesn't wrap
		//See: https://docs.oracle.com/javase/tutorial/uiswing/layout/visual.html
		BoxLayout bl = new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS);
		
		frame.getContentPane().setLayout(bl);
		
		//Create JPanel
		JPanel panel_service_1 = new JPanel();
		frame.getContentPane().add(panel_service_1);
		//Flow layout - items retain their size, are laid out horizontally and wrap

		panel_service_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		

		
	
	
		//Set Up Button ....
		JButton btnSend = new JButton("Click here to view your balance");
		
		//Add an action listener to our button
		btnSend.addActionListener(new ActionListener() {
			
			//implement action performed method
			//This will happen when the button is clicked
			public void actionPerformed(ActionEvent e) {

				int port = 50052;
				String host = "localhost";
				
				
				// build the channel
				ManagedChannel newChannel = ManagedChannelBuilder.forAddress(host,port).usePlaintext().build();
						
				// Creating a message that will be sent to the server
				
				balanceRequest cString =balanceRequest.newBuilder().setFirstString("Getting Balance").build(); 
				
				//create a stub .object that the client has that is a representation of the remote service. and is specific to the service
				//can have 2 types of stub - blocking and async. async is send off the request and this will allow you to carry on with your code while you wait for response
				
				BalanceBlockingStub bstub = BalanceGrpc.newBlockingStub(newChannel);

				//we can use this now to call the rpc
				
				balanceRequest response =	bstub.getFirstString(cString);
				// this returns the Balance
				balanceResponse response3 =	bstub.getBalanceResponseAmt(cString);
				JOptionPane.showMessageDialog(null, "Your Balance is:  "+ response3.getBalRes());
				
				//System.out.println(response.getFirstString());
				
				//This returns the stream of the last transactions
				
				Iterator<balanceTransactions> transactions;
				 transactions =	bstub.getBalanceTransactions(cString);
				    for (int i = 1; transactions.hasNext(); i++) {
				    	balanceTransactions response1 = transactions.next();
				    	JOptionPane.showMessageDialog(null,"\n" +response1.getTransaction() +"€" +response1.getLastTrans());
				    }
				
			try {
				newChannel.shutdown().awaitTermination(5,TimeUnit.SECONDS);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				System.out.println("Error closing down channel");
				e1.printStackTrace();
			}
				    
			
				
				
				
				
				

				

			}
		}); //End of setup button
		
		//Add button to the panel
		panel_service_1.add(btnSend);
		
		
		textResponse = new JTextArea();
		textResponse .setLineWrap(true);
		textResponse.setWrapStyleWord(true);
		
		JScrollPane scrollPane = new JScrollPane(textResponse);
		
		textResponse.setSize(new Dimension(15, 30));
		panel_service_1.add(scrollPane);
		
		/*
		JPanel panel_service_2 = new JPanel();
		frame.getContentPane().add(panel_service_2);
		
		JPanel panel_service_3 = new JPanel();
		frame.getContentPane().add(panel_service_3);
			*/
	}		
		
		
	
	
	
	
	
	/*
	 * Initialize the contents of the frame.
	 */
	
	
	
	
}
