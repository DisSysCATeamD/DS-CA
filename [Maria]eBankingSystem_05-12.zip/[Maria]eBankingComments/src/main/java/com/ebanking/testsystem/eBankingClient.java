package com.ebanking.testsystem;

import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import javax.jmdns.ServiceInfo;

import com.ebanking.testsystem.BalanceGrpc.BalanceBlockingStub;
import com.ebanking.testsystem.LoginGrpc.LoginBlockingStub;


import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;


public class eBankingClient {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		String host = "localhost";
		int port = 50051;
		
	//	ServiceInfo serviceInfo = JmDNSDiscovery.run("_grpc._tcp.local.");
	//	System.out.println("");
		
		//setup channel on the host and port above and it is going to communicate on the channel we setup
		ManagedChannel channel = ManagedChannelBuilder
				.forAddress(host, port)
				.usePlaintext()
				.build();
		
		//instance of our stub which has the login method on it which we can call
		LoginBlockingStub stub = LoginGrpc.newBlockingStub(channel);
		
		//try catch, to try connect to the server
		//the output from the proto file, so pass message from the client to the server, want to create a request using the LoginRequest object

	*/
		
	// **************** Get Balance and Transactions *********************************//	
		// Build a channel 
		int port = 50052;
		String host = "localhost"; 
		
/*		ServiceInfo serviceInfo;
		String service_type = "_http._tcp.local.";
		//Now retrieve the service info - all we are supplying is the service type
		serviceInfo = JmDNSDiscovery1.run(service_type);
		//Use the serviceInfo to retrieve the port
		int port = serviceInfo.getPort();
		String host = "localhost";
		//int port = 50052;
*/		
		
		// build the channel
		ManagedChannel newChannel = ManagedChannelBuilder.forAddress(host,port).usePlaintext().build();
				
		// 1. Creating a message that will be sent to the server and then sending a response back to let the user know that request was accepted

		balanceRequest cString =balanceRequest.newBuilder().setFirstString("Getting Balance").build(); 
		
		BalanceBlockingStub bstub = BalanceGrpc.newBlockingStub(newChannel);
		
		balanceRequest response =	bstub.getFirstString(cString);
		
		System.out.println(response.getFirstString()); // print out the response from the server that it received the request
		
		
		// 2. This will fetch the balance from server and the server will send the total back. We then print the result onto the console
		balanceResponse response3 =	bstub.getBalanceResponseAmt(cString);
		
		System.out.println("Your Balance is:  "+ response3.getBalRes());
		
		
		
		//3. This returns the stream of the last transactions. Using iterator here as there are more than one. It will cycle through and then print out the result 
		// of each transactions
		
		Iterator<balanceTransactions> transactions; 
		 transactions =	bstub.getBalanceTransactions(cString);
		    for (int i = 1; transactions.hasNext(); i++) {
		    	balanceTransactions response1 = transactions.next();
	            System.out.println("\n" +response1.getTransaction() +"€" +response1.getLastTrans());
		    }
		    
	// Error handling here to tell the user if the server malfunctioned
	try {
		newChannel.shutdown().awaitTermination(5,TimeUnit.SECONDS);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		System.out.println("Error closing down channel");
		e.printStackTrace();
	}
		    
	}
}
	



	


